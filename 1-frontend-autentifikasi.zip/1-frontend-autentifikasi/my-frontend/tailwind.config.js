/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html','./src/Components/Admin/**/*.{html,jsx}','./src/Components/Auth/**/*.{html,jsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
}


// npx tailwindcss -i ./src/css/input.css -o ./src/css/output.css --watch
