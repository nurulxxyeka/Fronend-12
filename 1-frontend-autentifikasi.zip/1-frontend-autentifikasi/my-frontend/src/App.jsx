import React from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import PostLogin from './Components/Auth/Login';
import PostRegister from './Components/Auth/Register';
import NotLogin from './Components/Auth/NotLogin';

import GetMahasiswa from './Components/Admin/GetMahasiswa';
import CreateMahasiswa from './Components/Admin/CreateMahasiswa';


function App() {
  
  return (
    <>
      <Router>
        <Routes>
          <Route path='/PostRegister' element={<PostRegister />} />
          <Route path='/PostLogin' element={<PostLogin />} />
          <Route path='/GetMahasiswa' element={ <GetMahasiswa /> } />
          <Route path='/CreateMahasiswa' element={ <CreateMahasiswa/> } />
          <Route path='*' element={<NotLogin/>}/>
        </Routes>
      </Router>
    </>
  )
}

export default App
