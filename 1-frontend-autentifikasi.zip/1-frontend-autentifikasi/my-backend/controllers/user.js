const connection =  require("../db/db");
const bcrypt = require("bcrypt");

module.exports = {

  postRegister:(req, res) => {
    const {username, password} = req.body;   
    const hashedPw = bcrypt.hashSync(password, 10);

    connection.query(`INSERT INTO user VALUES ('${username}','${hashedPw}')`, (err) => {
      if (err) {
        console.log("error: ", err);
        res.status(500).send({
            message: err.message || "Register gagal"
        });
      } else {
          res.send({username, hashedPw});
      }
    });
  },

  postLogin:(req, res) => {
    //cek kredensial pengguna (contoh sederhana)
    const {username, password} = req.body;

    connection.query(`SELECT * FROM user WHERE username = '${username}'`, (err, result) => {
        if (err) {
          console.log("error: ", err);
          res.status(500).send({
              message: err.message 
          });
        }
        else if (result.length > 0) {
          const user = result[0];
          const isMatch = bcrypt.compareSync(password, user.password);
          if (isMatch) {
              // Pengguna terautentikasi
              req.session.isAuthenticated = true;
              res.status(200).send('Berhasil login');            
          } else {
              // Pengguna tidak terautentikasi
              res.status(401).send('Password salah');            
          }
        } 
        else {
          //pengguna tidak terautentikasi
          res.status(401).send('Username salah');
        }
    });
  },

  //middleware untuk autentikasi
  authenticate:(req, res, next) => {
    if (req.session.isAuthenticated) {
        //pengguna sudah terautentikasi
        next();
    }  else {
        //pengguna belum terautentikasi
        res.status(401).send('Tidak Terautentikasi');
    }
  },

  getLogout: (req, res) => {
    //menghapus session pengguna
    req.session.destroy((err) => {
        if (err) {
            console.log(err);
        } else {
            res.send('Logout');
        }
    });
  },
};