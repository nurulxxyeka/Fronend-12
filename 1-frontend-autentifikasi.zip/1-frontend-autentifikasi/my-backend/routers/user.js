const express = require('express');
const routerUser = express.Router();
const ctrUser = require("../controllers/user");

routerUser.post('/register', ctrUser.postRegister );
routerUser.post('/login', ctrUser.postLogin );
routerUser.get('/logout', ctrUser.getLogout );


module.exports = routerUser; 