const express = require('express');
const session = require('express-session');
const routerMhs = require('./routers/mahasiswa');
const routerUser = require('./routers/user')
const app = express();
const port = 5000;
const cors = require('cors');

// Konfigurasi CORS
const corsOptions = {
    origin: 'http://localhost:5173',
    credentials: true  
    // Mengizinkan penggunaan kredensial (mis. cookies, authorization headers) dalam permintaan
};

app.use(cors(corsOptions));
app.use(express.json());
app.use(express.urlencoded({extended: true}));


//konfigurasi session
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 60000 //waktu
    }
  }));

  
app.use(routerUser);
app.use(routerMhs);


app.listen(port,() => {
    console.log('Server runing at port', port);
});